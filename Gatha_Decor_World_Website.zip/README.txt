GATHA DECOR WORLD WEBSITE

Files:
- index.html
- images/ (your supplied product photos)

How to use:
1. Open index.html in any browser to preview the website.
2. Before publishing, replace the placeholder phone number and email in index.html.
3. Upload the whole folder to your hosting/server.

No logo has been used, as requested. The brand name is presented as clean text.
